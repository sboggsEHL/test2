// src/renderer/components/Chart2.tsx
import React from 'react';
import '../styles/Chart.css';

export const Chart2 = () => {
  return (
    <div id="Chart2" className="chart">
      <p>Chart 2 Content</p>
    </div>
  );
};