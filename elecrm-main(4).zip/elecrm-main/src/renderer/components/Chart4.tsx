// src/renderer/components/Chart4.tsx
import React from 'react';
import '../styles/Chart.css';

export const Chart4 = () => {
  return (
    <div id="Chart4" className="chart">
      <p>Chart 4 Content</p>
    </div>
  );
};