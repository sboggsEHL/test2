// src/renderer/components/Chart3.tsx
import React from 'react';
import '../styles/Chart.css';

export const Chart3 = () => {
  return (
    <div id="Chart3" className="chart">
      <p>Chart 3 Content</p>
    </div>
  );
};