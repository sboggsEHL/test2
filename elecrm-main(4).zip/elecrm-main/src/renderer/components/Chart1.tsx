// src/renderer/components/Chart1.tsx
import React from 'react';
import '../styles/Chart.css';

export const Chart1 = () => {
  return (
    <div id="Chart1" className="chart">
      <p>Chart 1 Content</p>
    </div>
  );
};
