export type NotificationLead = {
  lead_id: string;
  state: string;
  first_name?: string;
  last_name?: string;
  phone_number?: string;
};

