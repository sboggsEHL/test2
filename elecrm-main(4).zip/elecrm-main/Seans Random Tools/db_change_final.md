**# Lead Database Normalization Strategy

## Current Architecture

1. **Lead Collection**

   - Multiple vendors (MRC, LMB, FRU, TransUnion) send leads to dedicated endpoints.

2. **Vendor-Specific Tables**

   - Each vendor stores data in its own table: `mrc`, `lower_my_bills`, `free_rate_update`, `transunion`.

3. **PostgreSQL Triggers**

   - Vendor triggers copy data from vendor tables → `combined_leads`.

4. **Application Access**
   - Node.js API & CRM read/write `combined_leads` directly.

### Why We're Normalizing

- `combined_leads` was a single big table with repeated columns, making maintenance/updates difficult.
- By **normalizing** and **transforming** data in parallel, we keep production safe, reduce redundancy, and standardize data.

## Step 1: Create Normalized Tables

We split data into **5** tables. One "parent" (`normalized_leads`) plus four "child" tables referencing the parent `id`.

```sql
-- normalized_leads
CREATE TABLE app.normalized_leads (
    id SERIAL PRIMARY KEY,
    global_id VARCHAR(255) UNIQUE,
    lead_id VARCHAR(255),
    status VARCHAR(50) DEFAULT 'new',
    lead_source VARCHAR(100),
    assigned_to VARCHAR(25),
    assigned_at TIMESTAMP WITHOUT TIME ZONE,
    created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITHOUT TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    exported BOOLEAN DEFAULT FALSE,
    ulid VARCHAR(36),
    price NUMERIC(15,2)
);

-- lead_personal_info
CREATE TABLE app.lead_personal_info (
    lead_id INTEGER PRIMARY KEY REFERENCES app.normalized_leads(id),
    first_name VARCHAR(255),
    middle_name VARCHAR(255),
    last_name VARCHAR(255),
    suffix VARCHAR(10),
    email VARCHAR(255),
    dob DATE,
    veteran BOOLEAN,
    credit INT,
    marital_status VARCHAR(50),
    first_name_b2 VARCHAR(255),
    last_name_b2 VARCHAR(255),
    gross_income NUMERIC(15,2)
);

-- lead_contact_info
CREATE TABLE app.lead_contact_info (
    lead_id INTEGER PRIMARY KEY REFERENCES app.normalized_leads(id),
    address VARCHAR(255),
    city VARCHAR(100),
    state VARCHAR(50),
    zip_code VARCHAR(20),
    home_phone VARCHAR(20),
    cell_phone VARCHAR(20)
);

-- lead_property_info
CREATE TABLE app.lead_property_info (
    lead_id INTEGER PRIMARY KEY REFERENCES app.normalized_leads(id),
    property_use VARCHAR(100),
    property_type VARCHAR(100),
    estimated_value NUMERIC(15,2)
);

-- lead_loan_info
CREATE TABLE app.lead_loan_info (
    lead_id INTEGER PRIMARY KEY REFERENCES app.normalized_leads(id),
    loan_purpose VARCHAR(100),
    mortgage_balance NUMERIC(15,2),
    second_mortgage_balance NUMERIC(15,2),
    desired_loan_amount NUMERIC(15,2),
    cash_outamt NUMERIC(15,2)
);
```

## Step 2: Create Transformation Functions

We have several **utility** functions that clean and standardize textual fields.

### 2.1 transform_with_underscores

Splits a string by `_`, then `initcap` each chunk, rejoining them with `_`.

```sql
CREATE OR REPLACE FUNCTION app.transform_with_underscores(p_str TEXT)
RETURNS TEXT AS $$
DECLARE
    parts TEXT[];
    i INT;
    transformed TEXT := '';
BEGIN
    IF p_str IS NULL OR p_str = '' THEN
        RETURN NULL;
    END IF;

    -- Lowercase everything first
    p_str := lower(p_str);

    -- Split into chunks by underscore
    parts := string_to_array(p_str, '_');

    FOR i IN array_lower(parts, 1)..array_upper(parts, 1) LOOP
        IF i > array_lower(parts, 1) THEN
            transformed := transformed || '_';  -- reinsert underscore
        END IF;
        transformed := transformed || initcap(parts[i]);
        -- e.g. "2-4" => "2-4", "unit" => "Unit"
    END LOOP;

    RETURN transformed;
END;
$$ LANGUAGE plpgsql;
```

### 2.2 transform_property_use

Maps known strings to `"PRIMARY"`, then does underscore-based capitalization if needed.

```sql
CREATE OR REPLACE FUNCTION app.transform_property_use(p_use TEXT)
RETURNS TEXT AS $$
DECLARE
    v_temp TEXT;
BEGIN
    IF p_use IS NULL OR p_use = '' THEN
        RETURN NULL;
    END IF;

    -- Known categories
    IF p_use ILIKE 'OWNEROCCUPIED'
       OR p_use ILIKE 'primary'
       OR p_use ILIKE 'Primary Residence'
    THEN
        v_temp := 'PRIMARY';
    ELSE
        v_temp := p_use;  -- keep original if not recognized
    END IF;

    -- Now apply underscores transform (to fix "2-4_UNIT" => "2-4_Unit", etc.)
    v_temp := app.transform_with_underscores(v_temp);
    RETURN v_temp;
END;
$$ LANGUAGE plpgsql;
```

### 2.3 transform_property_type

Similar to property_use. Known synonyms → "SFR", "CONDO", "TOWNHOME", "2-4_UNIT", "MULTI_FAM". Then uses `transform_with_underscores` to fix casing.

```sql
CREATE OR REPLACE FUNCTION app.transform_property_type(p_type TEXT)
RETURNS TEXT AS $$
DECLARE
    v_temp TEXT;
BEGIN
    IF p_type IS NULL OR p_type = '' THEN
        RETURN NULL;
    END IF;

    IF p_type ILIKE 'SINGLEFAMDET'
       OR p_type ILIKE 'single'
       OR p_type ILIKE 'Single Family'
    THEN
        v_temp := 'SFR';
    ELSIF p_type ILIKE 'condo'
       OR p_type ILIKE 'condominium'
       OR p_type ILIKE 'LOWRISECONDO'
    THEN
        v_temp := 'CONDO';
    ELSIF p_type ILIKE 'Town Home'
    THEN
        v_temp := 'TOWNHOME';
    ELSIF p_type ILIKE '2TO4UNITFAM'
    THEN
        v_temp := '2-4_UNIT';
    ELSIF p_type ILIKE 'multi'
    THEN
        v_temp := 'MULTI_FAM';
    ELSE
        v_temp := p_type;
    END IF;

    v_temp := app.transform_with_underscores(v_temp);
    RETURN v_temp;
END;
$$ LANGUAGE plpgsql;
```

### 2.4 transform_lead_source

Detects if it's MRC, sets `"mrc"`; otherwise keeps the original.

```sql
CREATE OR REPLACE FUNCTION app.transform_lead_source(
    p_lead_source TEXT,
    p_global_id TEXT,
    p_lead_id TEXT
)
RETURNS TEXT AS $$
DECLARE
    v_out TEXT;
BEGIN
    v_out := p_lead_source;

    IF p_lead_source ILIKE '%mrc%'
       OR p_global_id ILIKE '%-mrc%'
       OR p_lead_id ILIKE 'mrc%'
    THEN
        v_out := 'mrc';
    END IF;

    RETURN v_out;
END;
$$ LANGUAGE plpgsql;
```

### 2.5 transform_loan_purpose

Maps "R", "Refinance", "REFIPRIMARY", etc. → `"Refinance"`, "Cash Out" variations → `"Cash Out Refinance"`, "P/Purchase" → `"Purchase"`.

```sql
CREATE OR REPLACE FUNCTION app.transform_loan_purpose(p_purpose TEXT)
RETURNS TEXT AS $$
BEGIN
    IF p_purpose IS NULL OR p_purpose = '' THEN
        RETURN NULL;
    END IF;

    -- Refinance
    IF p_purpose ILIKE 'R'
       OR p_purpose ILIKE 'Refinance'
       OR p_purpose ILIKE 'Change My Mortgage Term'
       OR p_purpose ILIKE 'REFIPRIMARY'
    THEN
        RETURN 'Refinance';

    -- Cash Out Refinance
    ELSIF p_purpose ILIKE 'Cashout'
       OR p_purpose ILIKE 'Cash Out'
       OR p_purpose ILIKE 'Home Improvement'
       OR p_purpose ILIKE 'Heloc'
    THEN
        RETURN 'Cash Out Refinance';

    -- Purchase
    ELSIF p_purpose ILIKE 'P'
       OR p_purpose ILIKE 'Purchase'
    THEN
        RETURN 'Purchase';

    ELSE
        RETURN p_purpose;
    END IF;
END;
$$ LANGUAGE plpgsql;
```

### 2.6 transform_credit

Converts "excellent/good/fair/poor" → numeric scores, or tries to parse numeric strings.

```sql
CREATE OR REPLACE FUNCTION app.transform_credit(p_credit TEXT)
RETURNS INT AS $$
DECLARE
    v_score INT;
BEGIN
    IF p_credit ~ '^[0-9]+$' THEN
        v_score := p_credit::INT;
        RETURN v_score;
    END IF;

    IF p_credit ILIKE 'excellent' THEN
        RETURN 750;
    ELSIF p_credit ILIKE 'good' THEN
        RETURN 700;
    ELSIF p_credit ILIKE 'fair' THEN
        RETURN 650;
    ELSIF p_credit ILIKE 'poor' THEN
        RETURN 600;
    ELSIF p_credit ~ '^[0-9]{3}-[0-9]{3}$' THEN
        -- e.g. "670-700" => average
        RETURN (substring(p_credit from 1 for 3)::INT
                + substring(p_credit from 5 for 3)::INT) / 2;
    END IF;

    RETURN NULL;
END;
$$ LANGUAGE plpgsql;
```

### 2.7 transform_city

Converts city to **Title Case** (e.g., "SALT LAKE CITY" → "Salt Lake City").

```sql
CREATE OR REPLACE FUNCTION app.transform_city(p_city TEXT)
RETURNS TEXT AS $$
BEGIN
    IF p_city IS NULL OR p_city = '' THEN
        RETURN NULL;
    END IF;

    RETURN initcap(lower(p_city));
END;
$$ LANGUAGE plpgsql;
```

### 2.8 transform_address

Removes anything after first comma, trims, **strips trailing "."**, then `initcap`s.

```sql
CREATE OR REPLACE FUNCTION app.transform_address(p_address TEXT)
RETURNS TEXT AS $$
DECLARE
    v_address TEXT;
BEGIN
    IF p_address IS NULL OR p_address = '' THEN
        RETURN NULL;
    END IF;

    -- 1. Remove everything after the first comma
    IF position(',' IN p_address) > 0 THEN
        v_address := split_part(p_address, ',', 1);
    ELSE
        v_address := p_address;
    END IF;

    -- 2. Trim whitespace
    v_address := trim(v_address);

    -- 3. Strip trailing '.' if it exists
    IF v_address ~ '\.$' THEN
        v_address := substring(v_address FROM 1 FOR (length(v_address) - 1));
    END IF;

    -- 4. Convert to Title Case
    v_address := initcap(v_address);

    RETURN v_address;
END;
$$ LANGUAGE plpgsql;
```

## Step 3: Create Sync Function & Trigger

**We remove all references to** `tu_pk` (as requested). This function is **fully** updated to:

1. Call **all** transform functions.
2. Insert/update `normalized_leads` + child tables.

```sql
CREATE OR REPLACE FUNCTION app.sync_combined_to_normalized()
RETURNS trigger AS $$
DECLARE
    v_lead_id        INTEGER;
    v_existing_id    INTEGER;

    -- Variables for transformations
    v_lead_source    TEXT;
    v_credit_score   INT;
    v_address        TEXT;
    v_city           TEXT;
    v_prop_use       TEXT;
    v_prop_type      TEXT;
    v_loan_purpose   TEXT;
BEGIN
    -- 1) Transform lead_source
    v_lead_source := app.transform_lead_source(
        NEW.lead_source,
        NEW.global_id,
        NEW.lead_id
    );

    -- 2) Transform credit
    v_credit_score := app.transform_credit(NEW.credit);

    -- 3) Transform address
    v_address := app.transform_address(NEW.address);

    -- 4) Transform city
    v_city := app.transform_city(NEW.city);

    -- 5) Transform property_use & property_type
    v_prop_use  := app.transform_property_use(NEW.property_use);
    v_prop_type := app.transform_property_type(NEW.property_type);

    -- 6) Transform loan_purpose
    v_loan_purpose := app.transform_loan_purpose(NEW.loan_purpose);

    -------------------------------------------------------------------
    --  Check if a record already exists in normalized_leads by global_id
    -------------------------------------------------------------------
    SELECT id
      INTO v_existing_id
      FROM app.normalized_leads
     WHERE global_id = NEW.global_id;

    IF v_existing_id IS NULL THEN
        -- ========================================================
        --  INSERT (New lead in normalized_leads + child tables)
        -- ========================================================
        INSERT INTO app.normalized_leads (
            global_id,
            lead_id,
            status,
            lead_source,
            assigned_to,
            assigned_at,
            created_at,
            updated_at,
            exported,
            ulid,
            price
        )
        VALUES (
            NEW.global_id,
            NEW.lead_id,
            NEW.status,
            v_lead_source,
            NEW.assigned_to,
            NEW.assigned_at,
            NEW.created_at,
            NEW.updated_at,
            NEW.exported,
            NEW.ulid,
            NEW.price
        )
        RETURNING id INTO v_lead_id;

        -- Personal Info
        INSERT INTO app.lead_personal_info (
            lead_id,
            first_name,
            middle_name,
            last_name,
            suffix,
            email,
            dob,
            veteran,
            credit,
            marital_status,
            first_name_b2,
            last_name_b2,
            gross_income
        )
        VALUES (
            v_lead_id,
            NEW.first_name,
            NEW.middle_name,
            NEW.last_name,
            NEW.suffix,
            NEW.email,
            NEW.dob,
            NEW.veteran,
            v_credit_score,
            NEW.marital_status,
            NEW.first_name_b2,
            NEW.last_name_b2,
            NEW.gross_income
        );

        -- Contact Info
        INSERT INTO app.lead_contact_info (
            lead_id,
            address,
            city,
            state,
            zip_code,
            home_phone,
            cell_phone
        )
        VALUES (
            v_lead_id,
            v_address,
            v_city,
            NEW.state,
            NEW.zip_code,
            NEW.home_phone,
            NEW.cell_phone
        );

        -- Property Info
        INSERT INTO app.lead_property_info (
            lead_id,
            property_use,
            property_type,
            estimated_value
        )
        VALUES (
            v_lead_id,
            v_prop_use,
            v_prop_type,
            NEW.estimated_value
        );

        -- Loan Info
        INSERT INTO app.lead_loan_info (
            lead_id,
            loan_purpose,
            mortgage_balance,
            second_mortgage_balance,
            desired_loan_amount,
            cash_outamt
        )
        VALUES (
            v_lead_id,
            v_loan_purpose,
            NEW.mortgage_balance,
            NEW.second_mortgage_balance,
            NEW.desired_loan_amount,
            NEW.cash_outamt
        );

    ELSE
        -- ========================================================
        --  UPDATE (Existing lead in normalized_leads + child tables)
        -- ========================================================
        UPDATE app.normalized_leads
           SET status      = NEW.status,
               lead_source = v_lead_source,
               assigned_to = NEW.assigned_to,
               assigned_at = NEW.assigned_at,
               updated_at  = NEW.updated_at,
               exported    = NEW.exported,
               ulid        = NEW.ulid,
               price       = NEW.price
         WHERE id = v_existing_id;

        UPDATE app.lead_personal_info
           SET first_name     = NEW.first_name,
               middle_name    = NEW.middle_name,
               last_name      = NEW.last_name,
               suffix         = NEW.suffix,
               email          = NEW.email,
               dob            = NEW.dob,
               veteran        = NEW.veteran,
               credit         = v_credit_score,
               marital_status = NEW.marital_status,
               first_name_b2  = NEW.first_name_b2,
               last_name_b2   = NEW.last_name_b2,
               gross_income   = NEW.gross_income
         WHERE lead_id = v_existing_id;

        UPDATE app.lead_contact_info
           SET address    = v_address,
               city       = v_city,
               state      = NEW.state,
               zip_code   = NEW.zip_code,
               home_phone = NEW.home_phone,
               cell_phone = NEW.cell_phone
         WHERE lead_id = v_existing_id;

        UPDATE app.lead_property_info
           SET property_use    = v_prop_use,
               property_type   = v_prop_type,
               estimated_value = NEW.estimated_value
         WHERE lead_id = v_existing_id;

        UPDATE app.lead_loan_info
           SET loan_purpose            = v_loan_purpose,
               mortgage_balance        = NEW.mortgage_balance,
               second_mortgage_balance = NEW.second_mortgage_balance,
               desired_loan_amount     = NEW.desired_loan_amount,
               cash_outamt             = NEW.cash_outamt
         WHERE lead_id = v_existing_id;
    END IF;

    RETURN NULL;  -- no effect on the original operation
END;
$$ LANGUAGE plpgsql;


DROP TRIGGER IF EXISTS sync_combined_leads_trigger ON app.combined_leads;

CREATE TRIGGER sync_combined_leads_trigger
AFTER INSERT OR UPDATE ON app.combined_leads
FOR EACH ROW
EXECUTE FUNCTION app.sync_combined_to_normalized();
```

**Now** the system automatically normalizes every lead from `combined_leads` → `normalized_leads` + child tables with your data transformations.

## Step 4: Migrate Existing Data

We have a **batch-based** approach to re-sync old leads. This function does a no-op update on `combined_leads`, causing the new sync trigger to fire:

```sql
CREATE OR REPLACE FUNCTION app.migrate_existing_leads()
RETURNS void AS $$
DECLARE
    v_count INTEGER := 0;
BEGIN
    FOR i IN 1..10 LOOP
        UPDATE app.combined_leads
           SET updated_at = updated_at
         WHERE id IN (
            SELECT id
              FROM app.combined_leads
             WHERE id NOT IN (
                   SELECT cl.id
                     FROM app.combined_leads cl
                     JOIN app.normalized_leads nl ON cl.global_id = nl.global_id
                   )
             ORDER BY id
             LIMIT 1000
        );

        GET DIAGNOSTICS v_count = ROW_COUNT;
        RAISE NOTICE 'Migrated % leads in batch %', v_count, i;

        IF v_count = 0 THEN
            EXIT;
        END IF;
    END LOOP;

    RAISE NOTICE 'Migration complete';
END;
$$ LANGUAGE plpgsql;
```

### Usage

1. **Truncate** normalized tables to start fresh (optional):
   ```sql
   TRUNCATE TABLE app.lead_personal_info,
                 app.lead_contact_info,
                 app.lead_property_info,
                 app.lead_loan_info,
                 app.normalized_leads
   CASCADE;
   ```
2. **Run** the migration:
   ```sql
   SELECT app.migrate_existing_leads();
   ```
3. Each batch updates up to 1000 leads; watch the console for `NOTICE: Migrated X leads in batch Y`.

## Step 5: (Optional) Database Service Functions

Let your application call these functions instead of direct table access, for safer upgrades.

### 5.1 get_lead

```sql
CREATE OR REPLACE FUNCTION app.get_lead(p_global_id VARCHAR(255))
RETURNS SETOF app.combined_leads AS $$
BEGIN
    RETURN QUERY
        SELECT *
          FROM app.combined_leads
         WHERE global_id = p_global_id;
END;
$$ LANGUAGE plpgsql;
```

### 5.2 assign_lead

```sql
CREATE OR REPLACE FUNCTION app.assign_lead(
    p_global_id VARCHAR(255),
    p_assigned_to VARCHAR(25)
)
RETURNS BOOLEAN AS $$
BEGIN
    UPDATE app.combined_leads
       SET assigned_to = p_assigned_to,
           assigned_at = CURRENT_TIMESTAMP,
           status      = 'assigned',
           updated_at  = CURRENT_TIMESTAMP
     WHERE global_id = p_global_id;

    RETURN FOUND;  -- true if updated
END;
$$ LANGUAGE plpgsql;
```

## Step 6: (Optional) Compatibility View

You can create a view that **joins** all normalized tables to mimic the old `combined_leads` columns:

```sql
CREATE OR REPLACE VIEW app.combined_leads_view AS
SELECT
    nl.id,
    nl.global_id,
    nl.lead_id,
    -- no tu_pk
    lpi.first_name,
    lpi.middle_name,
    lpi.last_name,
    lpi.suffix,
    lpi.email,
    lpi.dob,
    lpi.veteran,
    lpi.credit,
    lpi.marital_status,
    lpi.first_name_b2,
    lpi.last_name_b2,
    lci.address,
    lci.city,
    lci.state,
    lci.zip_code,
    lci.home_phone,
    lci.cell_phone,
    lprop.property_use,
    lprop.property_type,
    lprop.estimated_value,
    lloan.loan_purpose,
    lloan.mortgage_balance,
    lloan.second_mortgage_balance,
    lloan.desired_loan_amount,
    lloan.cash_outamt,
    nl.status,
    nl.lead_source,
    nl.assigned_to,
    nl.assigned_at,
    nl.updated_at,
    nl.created_at,
    nl.exported,
    nl.ulid,
    nl.price
FROM app.normalized_leads nl
LEFT JOIN app.lead_personal_info  lpi   ON nl.id = lpi.lead_id
LEFT JOIN app.lead_contact_info  lci    ON nl.id = lci.lead_id
LEFT JOIN app.lead_property_info lprop  ON nl.id = lprop.lead_id
LEFT JOIN app.lead_loan_info     lloan  ON nl.id = lloan.lead_id;
```

Then your application can reference `app.combined_leads_view` in place of the original table if you want a fully normalized backend but the same column names.

# Conclusion

You now have:

1. **Normalized schema** (`normalized_leads` + 4 child tables).
2. **Transformation functions** for everything (lead source, loan purpose, city, addresses, property fields, credit).
3. **A single sync trigger** that automatically updates or inserts into the normalized schema whenever a row in `combined_leads` changes.
4. **Migration function** to backfill old data in small batches.
5. **Optional** service functions and a compatibility view.

**That's the final plan**—completely up to date with all last-minute changes (city transforms, address trailing period, underscores for property_type, removal of `tu_pk`, etc.).
**